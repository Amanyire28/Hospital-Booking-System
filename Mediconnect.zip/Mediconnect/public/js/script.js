// document.addEventListener('DOMContentLoaded', function() {
//     // Initialize form handlers and UI interactions
//     initializeNavbar();
//     initializeAppointmentForm();
//     initializeInquiryForm();
//     handleHashNavigation();
//     setupEscapeKeyHandler();
// });

// // Navbar functionality
// function initializeNavbar() {
//     const navbarCollapse = document.querySelector('.navbar-collapse');
//     const navbarToggler = document.querySelector('.navbar-toggler');

//     document.querySelectorAll('.nav-link').forEach(function(link) {
//         link.addEventListener('click', function() {
//             if (navbarCollapse?.classList.contains('show') && navbarToggler) {
//                 navbarToggler.click();
//             }
//         });
//     });
// }

// // Page navigation function
// function showPage(pageId) {
//     try {
//         const pages = document.querySelectorAll('.page-content');
//         if (!pages?.length) return true;

//         // Hide all pages and remove active states
//         pages.forEach(p => p.classList.remove('active-page'));
//         document.querySelectorAll('.nav-link').forEach(nav => nav.classList.remove('active'));

//         const targetPage = document.getElementById(pageId);
//         if (!targetPage) return true;

//         // Show target page and update UI
//         targetPage.classList.add('active-page');
//         const link = document.querySelector(`.nav-link[href="#${pageId}"]`);
//         if (link) link.classList.add('active');

//         // Handle scroll and focus
//         targetPage.scrollIntoView({ behavior: 'smooth', block: 'start' });
//         const focusable = targetPage.querySelector('input, select, textarea, button, a');
//         if (focusable?.focus) focusable.focus();

//         // Update URL
//         try {
//             history.replaceState?.(null, '', `#${pageId}`);
//         } catch (e) {
//             console.error('Error updating URL:', e);
//         }

//         return false;
//     } catch (e) {
//         console.error('Error in showPage:', e);
//         return true;
//     }
// }

// // Hash navigation handler
// function handleHashNavigation() {
//     const hash = (location.hash || '').replace('#', '');
//     if (hash) {
//         try {
//             showPage(hash);
//         } catch (e) {
//             console.error('Error handling hash navigation:', e);
//         }
//     }
// }

// // Escape key handler
// function setupEscapeKeyHandler() {
//     document.addEventListener('keydown', function(e) {
//         if (e.key === 'Escape' || e.key === 'Esc') {
//             const navbarCollapse = document.querySelector('.navbar-collapse');
//             const navbarToggler = document.querySelector('.navbar-toggler');
//             if (navbarCollapse?.classList.contains('show') && navbarToggler) {
//                 navbarToggler.click();
//                 navbarToggler.focus();
//             }
//         }
//     });
// }

// // Appointment form submission handler
// document.addEventListener('DOMContentLoaded', function(){
//   var form = document.getElementById('appointmentForm');
//   if (!form) return;

//   form.addEventListener('submit', function(e){
//     e.preventDefault();
    
//     // simple client-side validation (HTML5 required attributes handle most)
//     if (!form.checkValidity()){
//       form.reportValidity();
//       return;
//     }

//     // collect form data
//     var data = {
//       first_name: document.getElementById('firstName').value,
//       last_name: document.getElementById('lastName').value,
//       email: document.getElementById('email').value,
//       phone: document.getElementById('phone').value,
//       department: document.getElementById('department').value,
//       preferred_date: document.getElementById('date').value,
//       preferred_time: document.getElementById('time').value,
//       reason: document.getElementById('reason').value,
//       terms_accepted: document.getElementById('terms').checked ? 1 : 0
//     };

//     // Show loading state
//     const submitButton = form.querySelector('button[type="submit"]');
//     const originalButtonText = submitButton.innerHTML;
//     submitButton.disabled = true;
//     submitButton.innerHTML = 'Booking appointment...';

//     // Send to server
//     fetch('/api/appointments', {
//       method: 'POST',
//       headers: {
//         'Content-Type': 'application/json',
//         'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
//       },
//       body: JSON.stringify(data)
//     })
//     .then(response => response.json())
//     .then(data => {
//       if (data.message) {
//         alert('Success: ' + data.message);
//         form.reset();
//       } else {
//         throw new Error('Something went wrong');
//       }
//     })
//     .catch(error => {
//       console.error('Error:', error);
//       alert('Error: Could not book appointment. Please try again.');
//     })
//     .finally(() => {
//       // Restore button state
//       submitButton.disabled = false;
//       submitButton.innerHTML = originalButtonText;
//     });
//   });
// });
// ;

// // Inquiry form submission handler (client-side)
// document.addEventListener('DOMContentLoaded', function(){
//   var iForm = document.getElementById('inquiryForm');
//   if (!iForm) return;

//   iForm.addEventListener('submit', function(e){
//     e.preventDefault();
//     if (!iForm.checkValidity()){
//       iForm.reportValidity();
//       return;
//     }

//     var data = {
//       firstName: document.getElementById('inquiryFirstName')?.value || '',
//       lastName: document.getElementById('inquiryLastName')?.value || '',
//       email: document.getElementById('inquiryEmail')?.value || '',
//       phone: document.getElementById('inquiryPhone')?.value || '',
//       type: document.getElementById('inquiryType')?.value || '',
//       message: document.getElementById('message')?.value || ''
//     };

//     var name = (data.firstName || data.lastName) ? (data.firstName + ' ' + data.lastName).trim() : '';
//     alert('Thank you ' + (name || '') + '. Your inquiry has been received. We will respond to ' + data.email + ' shortly. (Demo)');
//     iForm.reset();
//   });
// });


// // End of js/script.js
