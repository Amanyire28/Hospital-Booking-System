<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>MediConnect - Hospital Appointment & Patient Inquiry System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Open+Sans:wght@300;400;600&display=swap" rel="stylesheet">
    <!-- Local stylesheet -->
    <link rel="stylesheet" href="{{ asset('style.css') }}">
    <!-- Toastr CSS for better notifications -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
</head>
<body>
    <!-- Skip link for keyboard users -->
    <a class="skip-link" href="#home">Skip to content</a>
    <nav class="navbar navbar-expand-lg navbar-light sticky-top" role="navigation" aria-label="Main navigation">
        <div class="container">
            <a class="navbar-brand" href="#"><i class="fas fa-clinic-medical me-2"></i>MEDICONNECT</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="{{route('home')}}">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{route('about')}}">About Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="{{ route('Bookappointment') }}">Book Appointment</a>
                    </li>
                    <!-- Contact page removed -->
                    <li class="nav-item">
                        <a class="nav-link" href="{{route('admin')}}"></a>
                    </li>
                </ul>
                
            </div>
        </div>
    </nav>

    <main id="appointment" class="page-content" role="main" aria-labelledby="appointment-title">
        <section class="section">
            <div class="container">
                <div class="section-title">
                    <h2 id="appointment-title">Book an Appointment</h2>
                    <p>Schedule your visit to the hospital with our easy online booking system</p>
                </div>
                
                <div class="row">
                    <div class="col-lg-8 mx-auto">
                        <div class="form-container">
                            <form id="appointmentForm" action="{{ route('Bookappointment.store') }}" method="POST">
                                @csrf
                                
                                @if ($errors->any())
                                    <div class="alert alert-danger">
                                        <p class="mb-1">Please fix the following issues:</p>
                                        <ul class="mb-0 ps-3">
                                            @foreach ($errors->all() as $error)
                                                <li>{{ $error }}</li>
                                            @endforeach
                                        </ul>
                                    </div>
                                @endif

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="firstName" class="form-label">First Name</label>
                                            <input type="text" class="form-control @error('first_name') is-invalid @enderror" id="firstName" name="first_name" value="{{ old('first_name') }}" required>
                                            @error('first_name')
                                                <div class="invalid-feedback">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="lastName" class="form-label">Last Name</label>
                                            <input type="text" class="form-control @error('last_name') is-invalid @enderror" id="lastName" name="last_name" value="{{ old('last_name') }}" required>
                                            @error('last_name')
                                                <div class="invalid-feedback">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="email" class="form-label">Email Address</label>
                                            <input type="email" class="form-control @error('email') is-invalid @enderror" id="email" name="email" value="{{ old('email') }}" required>
                                            @error('email')
                                                <div class="invalid-feedback">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="phone" class="form-label">Phone Number</label>
                                            <input type="tel" class="form-control @error('phone') is-invalid @enderror" id="phone" name="phone" value="{{ old('phone') }}" required>
                                            @error('phone')
                                                <div class="invalid-feedback">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="department" class="form-label">Select Department</label>
                                    <select class="form-control @error('department') is-invalid @enderror" id="department" name="department" required>
                                        <option value="">Choose a department</option>
                                        <option value="cardiology" {{ old('department') === 'cardiology' ? 'selected' : '' }}>Cardiology</option>
                                        <option value="pediatrics" {{ old('department') === 'pediatrics' ? 'selected' : '' }}>Pediatrics</option>
                                        <option value="orthopedics" {{ old('department') === 'orthopedics' ? 'selected' : '' }}>Orthopedics</option>
                                        <option value="neurology" {{ old('department') === 'neurology' ? 'selected' : '' }}>Neurology</option>
                                        <option value="ophthalmology" {{ old('department') === 'ophthalmology' ? 'selected' : '' }}>Ophthalmology</option>
                                        <option value="dentistry" {{ old('department') === 'dentistry' ? 'selected' : '' }}>Dentistry</option>
                                        <option value="general" {{ old('department') === 'general' ? 'selected' : '' }}>General Medicine</option>
                                    </select>
                                    @error('department')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="date" class="form-label">Preferred Date</label>
                                            <input type="date" class="form-control @error('preferred_date') is-invalid @enderror" id="date" name="preferred_date" value="{{ old('preferred_date') }}" required>
                                            @error('preferred_date')
                                                <div class="invalid-feedback">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="time" class="form-label">Preferred Time</label>
                                            <select class="form-control @error('preferred_time') is-invalid @enderror" id="time" name="preferred_time" required>
                                                <option value="">Select time</option>
                                                <option value="09:00" {{ old('preferred_time') === '09:00' ? 'selected' : '' }}>09:00 AM</option>
                                                <option value="10:00" {{ old('preferred_time') === '10:00' ? 'selected' : '' }}>10:00 AM</option>
                                                <option value="11:00" {{ old('preferred_time') === '11:00' ? 'selected' : '' }}>11:00 AM</option>
                                                <option value="12:00" {{ old('preferred_time') === '12:00' ? 'selected' : '' }}>12:00 PM</option>
                                                <option value="14:00" {{ old('preferred_time') === '14:00' ? 'selected' : '' }}>02:00 PM</option>
                                                <option value="15:00" {{ old('preferred_time') === '15:00' ? 'selected' : '' }}>03:00 PM</option>
                                                <option value="16:00" {{ old('preferred_time') === '16:00' ? 'selected' : '' }}>04:00 PM</option>
                                            </select>
                                            @error('preferred_time')
                                                <div class="invalid-feedback">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="reason" class="form-label">Reason for Visit</label>
                                    <textarea class="form-control @error('reason') is-invalid @enderror" id="reason" name="reason" rows="4" placeholder="Please describe your symptoms or reason for appointment">{{ old('reason') }}</textarea>
                                    @error('reason')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                
                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input @error('terms') is-invalid @enderror" id="terms" name="terms" {{ old('terms') ? 'checked' : '' }} required>
                                    <label class="form-check-label" for="terms">I agree to the terms and conditions</label>
                                    @error('terms')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>
                                
                                <button type="submit" class="btn btn-primary btn-lg w-100">Book Appointment</button>
                            </form>
                        </div>
                    </div>
                </div>
        </section>
    </main>

    <footer class="footer">
        <div class="container con">
            <div class="row">
                <div class="col-md-4 mb-3">
                    <h5>Social media</h5>
                    <div class="social-icons" aria-label="Social media links">
                        <a href="#" target="_blank">Facebook <i class="fab fa-facebook-f ms-1" aria-hidden="true"></i></a>
                        <a href="#" target="_blank">Twitter <i class="fab fa-twitter ms-1" aria-hidden="true"></i></a>
                        <a href="#" target="_blank">Instagram <i class="fab fa-instagram ms-1" aria-hidden="true"></i></a>
                        <a href="#" target="_blank">LinkedIn <i class="fab fa-linkedin-in ms-1" aria-hidden="true"></i></a>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <h5>Quick Links</h5>
                    <ul class="list-unstyled">
                            <li><a href="{{route('home')}}">Home</a></li>
                            <li><a href="{{route('about')}}">About Us</a></li>
                            <li><a href="{{route('Bookappointment')}}">Book Appointment</a></li>
                            <li><a href="{{route('admin')}}">Admin</a></li>
                    </ul>
                </div>
                <div class="col-md-4 mb-3">
                    <h5>Contact Info</h5>
                    <ul class="list-unstyled">
                        <li><i class="fas fa-map-marker-alt me-2"></i> Plot 123, Hospital Road, Kampala</li>
                        <li><i class="fas fa-phone me-2"></i> +256 700 123 456</li>
                        <li><i class="fas fa-envelope me-2"></i> info@mediconnect.ug</li>
                    </ul>
                </div>
            </div>
            <div class="text-center mt-3">
                <small>&copy; 2023 MediConnect. All rights reserved.</small>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <script src="{{ asset('js/script.js') }}"></script>
    
    @if(session('success'))
    <script>
        toastr.success("{{ session('success') }}");
    </script>
    @endif
    
    @if(session('error'))
    <script>
        toastr.error("{{ session('error') }}");
    </script>
    @endif
    
    <script>
        // Initialize toastr options
        toastr.options = {
            "closeButton": true,
            "progressBar": true,
            "positionClass": "toast-top-right",
            "timeOut": "5000"
        };
    </script>
</body>
</html>

