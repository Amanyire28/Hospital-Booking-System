<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>MediConnect Admin Dashboard</title>

  <!-- Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <!-- Custom Style -->
  <style>
    :root {
      --primary: #2a7de1;
      --dark: #0d1b2a;
      --light-bg: #f5f7fa;
      --sidebar-width: 240px;
    }

    body {
      font-family: 'Poppins', sans-serif;
      background-color: var(--light-bg);
      overflow-x: hidden;
      color: #333;
    }

    /* Sidebar */
    .sidebar {
      width: var(--sidebar-width);
      height: 100vh;
      position: fixed;
      left: 0;
      top: 0;
      background: var(--primary);
      color: #fff;
      display: flex;
      flex-direction: column;
      align-items: center;
      padding-top: 1rem;
      box-shadow: 2px 0 10px rgba(0,0,0,0.1);
    }

    .sidebar .brand {
      font-size: 1.5rem;
      font-weight: 600;
      margin-bottom: 2rem;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    .sidebar .nav-link {
      color: #ffffffcc;
      font-weight: 500;
      margin: 0.4rem 0;
      text-align: left;
      width: 100%;
      padding: 0.7rem 1.5rem;
      transition: 0.3s;
      border-radius: 10px;
    }

    .sidebar .nav-link:hover, 
    .sidebar .nav-link.active {
      background: rgba(255, 255, 255, 0.2);
      color: #fff;
    }

    /* Top bar */
    .topbar {
      margin-left: var(--sidebar-width);
      background: #fff;
      padding: 1rem 2rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
      box-shadow: 0 2px 10px rgba(0,0,0,0.05);
      position: sticky;
      top: 0;
      z-index: 1000;
    }

    .topbar h5 {
      font-weight: 600;
      color: var(--dark);
    }

    /* Main Content */
    .main-content {
      margin-left: var(--sidebar-width);
      padding: 2rem;
    }

    .card-box {
      background: #fff;
      border-radius: 12px;
      box-shadow: 0 3px 10px rgba(0,0,0,0.05);
      padding: 1.5rem;
      transition: transform 0.3s;
    }

    .card-box:hover {
      transform: translateY(-4px);
    }

    .card-box i {
      font-size: 1.8rem;
      color: var(--primary);
      margin-bottom: 0.5rem;
    }

    .card-box h6 {
      color: var(--dark);
      font-weight: 600;
    }

    .table-container {
      background: #fff;
      border-radius: 12px;
      padding: 1.5rem;
      box-shadow: 0 3px 10px rgba(0,0,0,0.05);
      margin-top: 1.5rem;
    }

    footer {
      margin-left: var(--sidebar-width);
      background: #fff;
      padding: 1rem;
      text-align: center;
      font-size: 0.9rem;
      border-top: 1px solid #e9ecef;
      color: #6c757d;
    }

    @media (max-width: 991px) {
      .sidebar {
        position: relative;
        width: 100%;
        height: auto;
        flex-direction: row;
        justify-content: space-around;
        padding: 1rem 0;
      }

      .topbar, .main-content, footer {
        margin-left: 0;
      }
    }
  </style>
</head>

<body>
  <!-- Sidebar -->
  <div class="sidebar">
    <div class="brand"><i class="fas fa-clinic-medical me-2"></i>Admin</div>
    <a href="#" class="nav-link active"><i class="fas fa-table me-2"></i>Dashboard</a>
    <a href="#" class="nav-link"><i class="fas fa-calendar-check me-2"></i>Appointments</a>

  <!-- Hidden logout form -->
<form id="logout-form" method="POST" action="{{ route('logout') }}" style="display: none;">
    @csrf
</form>

<!-- Visible logout link -->
<a href="{{ route('logout') }}" 
   class="nav-link text-danger"
   onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
   <i class="fas fa-sign-out-alt me-2"></i>Logout
</a>


  </div>

  <!-- Top Bar -->
  <div class="topbar">
    <h5>Welcome, Admin</h5>
    <div>
      <i class="fas fa-bell me-3 text-primary"></i>
      <img src="https://cdn-icons-png.flaticon.com/512/3135/3135715.png" alt="Admin" width="40" height="40" class="rounded-circle border">
    </div>
  </div>

  <!-- Main Content -->
  <div class="main-content">
    <h3 class="mb-4 fw-bold">Dashboard Overview</h3>
    <div class="row g-4">
      <div class="col-md-3">
        <div class="card-box text-center">
          <i class="fas fa-calendar-check"></i>
          <h6>Appointments</h6>
          <h4 class="fw-bold">48</h4>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card-box text-center">
          <i class="fas fa-user-md"></i>
          <h6>Doctors</h6>
          <h4 class="fw-bold">12</h4>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card-box text-center">
          <i class="fas fa-users"></i>
          <h6>Patients</h6>
          <h4 class="fw-bold">203</h4>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card-box text-center">
          <i class="fas fa-envelope-open-text"></i>
          <h6>Messages</h6>
          <h4 class="fw-bold">5</h4>
        </div>
      </div>
    </div>

    <div class="table-container mt-5">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h5 class="fw-semibold">Recent Appointments</h5>
        <button class="btn btn-primary btn-sm"><i class="fas fa-plus me-1"></i>Add New</button>
      </div>
        @if(session('success'))
    <div class="alert alert-success">
        {{ session('success') }}
    </div>
      @endif

      <table class="table table-hover align-middle">
        <thead class="table-primary">
          <tr>
            <th>#</th>
            <th>Name</th>
            <th>Email Address</th>
            <th>Department</th>
            <th>Date</th>
            <th>Time</th>
            <th>Reason</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          @foreach($records as $index => $row)
          <tr>
            <td>{{ $index + 1 }}</td>
            <td>{{ $row->name }}</td>
            <td>{{ $row->email }}</td>
            <td>{{ $row->department }}</td>
            <td>{{ $row->preferred_date }}</td>
            <td>{{ $row->preferred_time }}</td>
            <td>{{ $row->reason }}</td>
            <td><span class="badge bg-success">Confirmed</span></td>
            <td>
              <a href="{{ route('appointments.edit', $row->id) }}" class="btn btn-sm btn-warning">
                <i class="fas fa-edit"></i>
              </a>
              <form action="{{route ('appointments.destroy', $row->id)}}" method="POST">
                @csrf
                @method('DELETE')
                <button class="btn btn-sm btn-danger"><i class="fas fa-trash"></i></button>
              </form>
              
            </td>
          </tr>
          @endforeach
        </tbody>
      </table>
    </div>
  </div>

  <!-- Footer -->
  <footer>
    &copy; {{ date('Y') }} MediConnect Admin Dashboard — All Rights Reserved
  </footer>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
