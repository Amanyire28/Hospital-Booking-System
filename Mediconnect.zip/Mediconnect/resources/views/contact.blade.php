<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Contact Removed — MediConnect</title>
  <meta http-equiv="refresh" content="3;url=home.html">
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <main style="max-width:800px;margin:80px auto;padding:20px;text-align:center;font-family:Arial,Helvetica,sans-serif;">
    <h1>Contact page removed</h1>
    <p>The contact/inquiry page has been removed from this site. You will be redirected back to the homepage shortly.</p>
    <p>If you are not redirected automatically, <a href="home.html">click here to go to the homepage</a>.</p>
  </main>
  <script>setTimeout(function(){ location.href = 'home.html'; }, 3000);</script>
</body>
</html>