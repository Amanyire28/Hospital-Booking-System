<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MediConnect - Hospital Appointment & Patient Inquiry System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Open+Sans:wght@300;400;600&display=swap" rel="stylesheet">
    <!-- Local stylesheet -->
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- Skip link for keyboard users -->
    <a class="skip-link" href="#home">Skip to content</a>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light sticky-top" role="navigation" aria-label="Main navigation">
        <div class="container">
            <a class="navbar-brand" href="#"><i class="fas fa-clinic-medical me-2"></i>MEDICONNECT</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto align-items-center">
                    <li class="nav-item">
                        <a class="nav-link active" href="{{route('home')}}" onclick="showPage('home')">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{route('about')}}" onclick="showPage('about')">About Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('Bookappointment') }}" onclick="return showPage('appointment')">Book Appointment</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="{{route('admin')}}" onclick="showPage('admin.html')">Admin</a>
                    </li>

                    <!-- 🔐 Authentication Buttons -->
                    @if (Route::has('login'))
                        @auth
                            <li class="nav-item ms-3">
                                <a href="{{ url('/dashboard') }}" class="btn btn-success btn-sm px-3">
                                    <i class="fas fa-user-shield me-1"></i> Dashboard
                                </a>
                            </li>
                        @else
                            <li class="nav-item ms-3">
                                <a href="{{ route('login') }}" class="btn btn-outline-primary btn-sm px-3">
                                    <i class="fas fa-sign-in-alt me-1"></i> Log In
                                </a>
                            </li>
                            @if (Route::has('register'))
                                <li class="nav-item ms-2">
                                    <a href="{{ route('register') }}" class="btn btn-primary btn-sm px-3">
                                        <i class="fas fa-user-plus me-1"></i> Register
                                    </a>
                                </li>
                            @endif
                        @endauth
                    @endif
                </ul>
            </div>
        </div>
    </nav>

    <main id="home" class="page-content active-page" role="main" aria-labelledby="hero-title">
        
        <section class="hero" role="region" aria-label="Hero">
            <div class="container">
                <h1 id="hero-title">Your Health, Our Priority</h1>
                <p>MediConnect provides a modern solution for hospital appointments and patient inquiries, making healthcare more accessible and efficient for everyone.</p>
                <div class="mt-4">
                    <button class="btn btn-light btn-lg me-3" onclick="showPage('appointment')">Book Appointment</button>
                    <button class="btn btn-outline-light btn-lg me-3" onclick="showPage('about')">Learn More</button>

                    <!-- 👇 Added Authentication Buttons in Hero Section -->
                    @if (Route::has('login'))
                        @auth
                            <a href="{{ url('/dashboard') }}" class="btn btn-success btn-lg mt-2">
                                Go to Dashboard
                            </a>
                        @else
                            <a href="{{ route('login') }}" class="btn btn-primary btn-lg mt-2 me-2">Log In</a>
                            @if (Route::has('register'))
                                <a href="{{ route('register') }}" class="btn btn-outline-primary btn-lg mt-2">Register</a>
                            @endif
                        @endauth
                    @endif
                </div>
            </div>
        </section>

        <section class="section">
            <div class="container">
                <div class="section-title">
                    <h2>Our Services</h2>
                    <p>MediConnect offers a comprehensive digital platform to streamline hospital operations and improve patient experience.</p>
                </div>
                <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <div class="feature-box">
                            <div class="feature-icon">
                                <i class="fas fa-calendar-check"></i>
                            </div>
                            <h4>Easy Appointment Booking</h4>
                            <p>Schedule your medical appointments online without visiting the hospital. Choose your preferred date and time.</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="feature-box">
                            <div class="feature-icon">
                                <i class="fas fa-comments"></i>
                            </div>
                            <h4>Health Inquiries</h4>
                            <p>Submit your health-related questions and receive responses from qualified medical professionals.</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="feature-box">
                            <div class="feature-icon">
                                <i class="fas fa-user-md"></i>
                            </div>
                            <h4>Expert Medical Staff</h4>
                            <p>Access to qualified doctors and specialists with extensive experience in various medical fields.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="section bg-light">
            <div class="container">
                <div class="section-title">
                    <h2>How It Works</h2>
                    <p>Simple steps to book your appointment or make an inquiry through MediConnect</p>
                </div>
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="text-center mb-4">
                            <h4>Create Account</h4>
                            <p>Register with your basic information to get started.</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="text-center mb-4">
                            <h4>Book Appointment</h4>
                            <p>Select your preferred date, time and department.</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="text-center mb-4">
                            <h4>Get Confirmation</h4>
                            <p>Receive confirmation of your booking via email or SMS.</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="text-center mb-4">
                            <h4>Visit Hospital</h4>
                            <p>Arrive at the hospital at your scheduled time.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
    
    <footer class="footer">
        <div class="container con">
            <div class="row">
                <div class="col-md-4 mb-3">
                    <h5>Social media</h5>
                    <div class="social-icons" aria-label="Social media links">
                        <a href="https://www.fa-facebook.com/MediConnectHospital" target="_blank">Facebook <i class="fab fa-facebook-f ms-1" aria-hidden="true"></i></a>
                        <a href="https://www.fa-twitter.com/MediConnectHospital" target="_blank">Twitter <i class="fab fa-twitter ms-1" aria-hidden="true"></i></a>
                        <a href="https://www.fa-instagram.com/MediConnectHospital" target="_blank">Instagram <i class="fab fa-instagram ms-1" aria-hidden="true"></i></a>
                        <a href="https://www.fa-linkedin-in.com/MediConnectHospital" target="_blank">LinkedIn <i class="fab fa-linkedin-in ms-1" aria-hidden="true"></i></a>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <h5>Quick Links</h5>
                    <ul class="list-unstyled">
                        <li><a href="home.html" onclick="showPage('home')">Home</a></li>
                        <li><a href="about.html" onclick="showPage('about')">About Us</a></li>
                        <li><a href="Bookappointment.html" onclick="showPage('Bookappointment')">Book Appointment</a></li>
                        <li><a href="admin.html" onclick="showPage('admin')">Admin</a></li>
                    </ul>
                </div>
                <div class="col-md-4 mb-3">
                    <h5>Contact Info</h5>
                    <ul class="list-unstyled">
                        <li><i class="fas fa-map-marker-alt me-2"></i> Plot 123, Hospital Road, Kampala</li>
                        <li><i class="fas fa-phone me-2"></i> +256 700 123 456</li>
                        <li><i class="fas fa-envelope me-2"></i> info@mediconnect.ug</li>
                    </ul>
                </div>
            </div>
            <div class="text-center mt-3">
                <small>&copy; 2023 MediConnect. All rights reserved.</small>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/script.js"></script>
</body>
</html>
