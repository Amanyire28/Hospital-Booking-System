<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Appointment;
use App\Models\User;
use Illuminate\Support\Str;

class HomeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('home');
    }
    public function about()
    {
        return view('about');
    }
    public function Bookappointment()
    {
        return view('Bookappointment');
    }
    public function admin(){
        return view('admin');
    }
    public function contact(){
        return view('contact');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // Validate the request data
        $validatedData = $request->validate([
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'phone' => 'required|string|max:20',
            'department' => 'required|string|in:cardiology,pediatrics,orthopedics,neurology,ophthalmology,dentistry,general',
            'preferred_date' => [
                'required',
                'date',
                'after_or_equal:today',
            ],
            'preferred_time' => [
                'required',
                'date_format:H:i',
                function ($attribute, $value, $fail) {
                    $hour = (int) substr($value, 0, 2);
                    if ($hour < 9 || $hour > 16) {
                        $fail('Please select a time between 9 AM and 4 PM.');
                    }
                },
            ],
            'reason' => 'required|string|min:10',
            'terms' => 'required|accepted'
        ], [
            'first_name.required' => 'Please enter your first name',
            'last_name.required' => 'Please enter your last name',
            'email.required' => 'Please enter your email address',
            'email.email' => 'Please enter a valid email address',
            'phone.required' => 'Please enter your phone number',
            'department.required' => 'Please select a department',
            'department.in' => 'Please select a valid department',
            'preferred_date.required' => 'Please select your preferred date',
            'preferred_date.after_or_equal' => 'Please select a date from today onwards',
            'preferred_time.required' => 'Please select your preferred time',
            'preferred_time.date_format' => 'Please select a valid time',
            'reason.required' => 'Please provide a reason for your visit',
            'reason.min' => 'Please provide more details about your reason for visit (at least 10 characters)',
            'terms.accepted' => 'You must accept the terms and conditions'
        ]);

        try {
            // Find or create user
            $user = User::firstOrCreate(
                ['email' => $validatedData['email']],
                [
                    'name' => $validatedData['first_name'] . ' ' . $validatedData['last_name'],
                    'phone' => $validatedData['phone'],
                    'password' => bcrypt(Str::random(16)) // Generate random password for new users
                ]
            );

            // Create the appointment
            $appointment = Appointment::create([
                'user_id' => $user->id,
                'department' => $validatedData['department'],
                'preferred_date' => $validatedData['preferred_date'],
                'preferred_time' => $validatedData['preferred_time'],
                'reason' => $validatedData['reason']
            ]);

            \Log::info('Appointment booked successfully', [
                'user_id' => $user->id,
                'appointment_id' => $appointment->id,
                'date' => $validatedData['preferred_date'],
                'time' => $validatedData['preferred_time']
            ]);

            return redirect()->route('Bookappointment')
                ->with('success', 'Appointment booked successfully! We will contact you shortly.');
            
        } catch (\Exception $e) {
            \Log::error('Appointment booking failed', [
                'error' => $e->getMessage(),
                'data' => $validatedData
            ]);

            return redirect()->route('Bookappointment')
                ->with('error', 'There was an error booking your appointment. Please try again.')
                ->withInput();
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
