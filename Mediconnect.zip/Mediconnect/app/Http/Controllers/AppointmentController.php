<?php

namespace App\Http\Controllers;

use App\Models\Appointment;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;


class AppointmentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }
public function index()
{
    // Join users and appointments
    $records = DB::table('appointments')
        ->join('users', 'appointments.user_id', '=', 'users.id')
        ->select(
            'users.name',
            'appointments.id',
            'users.email',
            'appointments.department',
            'appointments.preferred_date',
            'appointments.preferred_time',
            'appointments.reason'
        )
        ->get();

    // Send data to admin.blade.php
    return view('admin', compact('records'));
}

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // Validate the request data
        $validatedData = $request->validate([
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'phone' => 'required|string|max:20',
            'department' => 'required|string',
            'preferred_date' => 'required|date_format:m/d/Y',
            'preferred_time' => 'required',
            'reason' => 'required|string',
            'terms_accepted' => 'required|accepted'
        ]);

        // Find or create user
        $user = User::firstOrCreate(
            ['email' => $validatedData['email']],
            [
                'name' => $validatedData['first_name'] . ' ' . $validatedData['last_name'],
                'phone' => $validatedData['phone'],
                'password' => bcrypt(Str::random(16)) // Generate a random password if new user
            ]
        );

        // Create the appointment
        $appointment = Appointment::create([
            'user_id' => $user->id,
            'department' => $validatedData['department'],
            'preferred_date' => \Carbon\Carbon::createFromFormat('m/d/Y', $validatedData['preferred_date'])->format('Y-m-d'),
            'preferred_time' => $validatedData['preferred_time'],
            'reason' => $validatedData['reason']
        ]);

        // Return response
        return response()->json([
            'message' => 'Appointment booked successfully',
            'appointment' => $appointment
        ], 201);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Appointment  $appointment
     * @return \Illuminate\Http\Response
     */
    public function show(Appointment $appointment)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Appointment  $appointment
     * @return \Illuminate\Http\Response
     */
   

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Appointment  $appointment
     * @return \Illuminate\Http\Response
     */


    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Appointment  $appointment
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $appointment = Appointment::findOrFail($id);
        $appointment->delete();

        return redirect()->route('admin')->with('success', 'Appointment deleted successfully.');
    }

    public function edit($id)
{
    $appointment = \App\Models\Appointment::findOrFail($id);
    return view('edit-appointment', compact('appointment'));
}

public function update(Request $request, $id)
{
    $validatedData = $request->validate([
        'department' => 'required|string',
        'preferred_date' => 'required|date',
        'preferred_time' => 'required',
        'reason' => 'required|string'
    ]);

    $appointment = \App\Models\Appointment::findOrFail($id);
    $appointment->update($validatedData);

    return redirect()->route('admin')->with('success', 'Appointment updated successfully.');
}

}
