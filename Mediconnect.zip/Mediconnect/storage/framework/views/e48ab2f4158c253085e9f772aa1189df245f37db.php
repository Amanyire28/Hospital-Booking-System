<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Appointment - MediConnect</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
    <h2 class="mb-4 text-center">Edit Appointment</h2>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Oops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('appointments.update', $appointment->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <label for="department" class="form-label">Department</label>
            <input type="text" class="form-control" name="department" value="<?php echo e($appointment->department); ?>" required>
        </div>

        <div class="row">
            <div class="col-md-6 mb-3">
                <label for="preferred_date" class="form-label">Preferred Date</label>
                <input type="date" class="form-control" name="preferred_date" value="<?php echo e($appointment->preferred_date); ?>" required>
            </div>

            <div class="col-md-6 mb-3">
                <label for="preferred_time" class="form-label">Preferred Time</label>
                <input type="time" class="form-control" name="preferred_time" value="<?php echo e($appointment->preferred_time); ?>" required>
            </div>
        </div>

        <div class="mb-3">
            <label for="reason" class="form-label">Reason for Visit</label>
            <textarea class="form-control" name="reason" rows="3" required><?php echo e($appointment->reason); ?></textarea>
        </div>

        <div class="d-flex justify-content-between">
            <a href="<?php echo e(route('admin')); ?>" class="btn btn-secondary">Back</a>
            <button type="submit" class="btn btn-success">Update Appointment</button>
        </div>
    </form>
</div>
</body>
</html>
<?php /**PATH C:\Users\Admin\Desktop\Mediconnect\resources\views/edit-appointment.blade.php ENDPATH**/ ?>