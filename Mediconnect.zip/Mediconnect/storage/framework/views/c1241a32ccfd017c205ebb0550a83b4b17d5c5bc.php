<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Page</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Open+Sans:wght@300;400;600&display=swap" rel="stylesheet">
    <!-- Local stylesheet -->
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- Skip link for keyboard users -->
    <a class="skip-link" href="#main-about">Skip to content</a>
     <nav class="navbar navbar-expand-lg navbar-light sticky-top" role="navigation" aria-label="Main navigation">
        <div class="container">
            <a class="navbar-brand" href="#"><i class="fas fa-clinic-medical me-2"></i>MEDICONNECT</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('home')); ?>">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="<?php echo e(route('about')); ?>">About Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('Bookappointment')); ?>" onclick="return showPage('appointment')">Book Appointment</a>
                    </li>
                    <!-- Contact page removed -->
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('admin')); ?>" onclick="showPage('admin.html')"></a>
                    </li>
                </ul>
                
            </div>
        </div>
    </nav>


  <main id="main-about">
    <!-- Hero Section -->
    <section class="about-hero">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <h1>About MediConnect</h1>
                    <p class="lead">Bringing digital convenience to healthcare management through innovative solutions and compassionate care.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Mission & Values Section -->
    <section class="mission-section">
        <div class="container">
            <div class="row g-4">
                <div class="col-md-6 col-lg-3">
                    <div class="mission-card">
                        <div class="icon-wrapper">
                            <i class="fas fa-bullseye"></i>
                        </div>
                        <h2>Our Mission</h2>
                        <p>To make hospital appointments and patient inquiries seamless, efficient, and accessible through innovative digital solutions.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="mission-card">
                        <div class="icon-wrapper">
                            <i class="fas fa-users"></i>
                        </div>
                        <h2>Our Team</h2>
                        <p>We have a team of qualified doctors, nurses and IT professionals working together to ensure quality healthcare service delivery.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="mission-card">
                        <div class="icon-wrapper">
                            <i class="fas fa-heartbeat"></i>
                        </div>
                        <h2>Our Values</h2>
                        <p>We value compassion, professionalism, integrity and innovation in every aspect of healthcare service.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="mission-card">
                        <div class="icon-wrapper">
                            <i class="fas fa-laptop-medical"></i>
                        </div>
                        <h2>Our Technology</h2>
                        <p>MediConnect uses secured medical systems to manage patient data, appointments, and doctor schedules efficiently.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Departments Section -->
    <section class="departments-section">
        <div class="container">
            <div class="section-title text-center">
                <h2>Our Departments</h2>
                <p>Specialized care for every need</p>
            </div>
            <div class="row g-4">
                <div class="col-md-6 col-lg-3">
                    <div class="department-card">
                        <div class="icon-circle">
                            <i class="fas fa-baby"></i>
                        </div>
                        <h4>Pediatrics</h4>
                        <p>Comprehensive healthcare for infants, children, and adolescents.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="department-card">
                        <div class="icon-circle">
                            <i class="fas fa-brain"></i>
                        </div>
                        <h4>Neurology</h4>
                        <p>Expert care for disorders of the nervous system.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="department-card">
                        <div class="icon-circle">
                            <i class="fas fa-eye"></i>
                        </div>
                        <h4>Ophthalmology</h4>
                        <p>Diagnosis and treatment of eye diseases and vision problems.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="department-card">
                        <div class="icon-circle">
                            <i class="fas fa-tooth"></i>
                        </div>
                        <h4>Dentistry</h4>
                        <p>Complete dental care for all ages and dental conditions.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
  </main>
  <footer class="footer">
        <div class="container con">
            <div class="row">
                <div class="col-md-4 mb-3">
                    <h5>Social media</h5>
                    <div class="social-icons" aria-label="Social media links">
                        <a href="https://www.fa-facebook.com/MediConnectHospital" target="_blank">Facebook <i class="fab fa-facebook-f ms-1" aria-hidden="true"></i></a>
                        <a href="https://www.fa-twitter.com/MediConnectHospital" target="_blank">Twitter <i class="fab fa-twitter ms-1" aria-hidden="true"></i></a>
                        <a href="https://www.fa-instagram.com/MediConnectHospital" target="_blank">Instagram <i class="fab fa-instagram ms-1" aria-hidden="true"></i></a>
                        <a href="https://www.fa-linkedin-in.com/MediConnectHospital" target="_blank">LinkedIn <i class="fab fa-linkedin-in ms-1" aria-hidden="true"></i></a>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <h5>Quick Links</h5>
                    <ul class="list-unstyled">
                        <li><a href="home.html" onclick="showPage('home')">Home</a></li>
                        <li><a href="about.html" onclick="showPage('about')">About Us</a></li>
                        <li><a href="Bookappointment.html" onclick="showPage('Bookappointment')">Book Appointment</a></li>
                        <li><a href="admin.html" onclick="showPage('admin')">Admin</a></li>
                    </ul>
                </div>
                <div class="col-md-4 mb-3">
                    <h5>Contact Info</h5>
                    <ul class="list-unstyled">
                        <li><i class="fas fa-map-marker-alt me-2"></i> Plot 123, Hospital Road, Kampala</li>
                        <li><i class="fas fa-phone me-2"></i> +256 700 123 456</li>
                        <li><i class="fas fa-envelope me-2"></i> info@mediconnect.ug</li>
                    </ul>
                </div>
            </div>
            <div class="text-center mt-3">
                <small>&copy; 2023 MediConnect. All rights reserved.</small>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Main JavaScript -->
    <script src="js/script.js"></script>
</body>
</html><?php /**PATH C:\Users\Admin\Desktop\Mediconnect\resources\views/about.blade.php ENDPATH**/ ?>