<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAppointmentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
       
        Schema::create('appointments', function (Blueprint $table) {
           $table->id();
            $table->unsignedBigInteger('user_id'); // Foreign key
            $table->string('department');
            $table->date('preferred_date');
            $table->time('preferred_time');
            $table->text('reason');
            $table->timestamps();

             $table->foreign('user_id')
                  ->references('user_id')
                  ->on('users')
                  ->onDelete('cascade'); // delete appointments if user is deleted
        });
    }
    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('appointments');
    }
}
